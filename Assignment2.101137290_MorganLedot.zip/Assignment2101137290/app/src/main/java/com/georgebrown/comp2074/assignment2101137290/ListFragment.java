package com.georgebrown.comp2074.assignment2101137290;


import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class ListFragment extends Fragment {

    ListView lv;
    ArrayList<String> al;
    FloatingActionButton btnAdd;

    ArrayAdapter<String> arrayAdapter;
    public SQLiteDatabase db;
    public DBHandler dbh;
    Bundle bundle;

    public ListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_list, container, false);
        lv = v.findViewById(R.id.list_item);

        al =new ArrayList<String>();
        arrayAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,al);
        lv.setAdapter(arrayAdapter);
        btnAdd = v.findViewById(R.id.buttonAdd);


        dbh = new DBHandler(getContext());
        db = dbh.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM items_table;",null);
        c.moveToFirst();

        do {
            String IN = c.getString(c.getColumnIndex("item_name"));
            arrayAdapter.add(IN);

        } while (c.moveToNext());



        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String itemName = al.get(position);
                MainActivity MA = (MainActivity) getActivity();
                MA.f1(itemName,position);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fm = getFragmentManager();
                FragmentTransaction fT = fm.beginTransaction();
                Fragment AI = new AddItem();
                fT.replace(R.id.frameMain,AI);
                fT.addToBackStack(null);
                fT.commit();
            }
        });



        return v;
    }

}
