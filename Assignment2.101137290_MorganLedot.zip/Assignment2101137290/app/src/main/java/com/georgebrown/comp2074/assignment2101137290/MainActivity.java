package com.georgebrown.comp2074.assignment2101137290;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction fT = manager.beginTransaction();
        ListFragment fL = new ListFragment();
        fT.add(R.id.frameMain,fL);
        fT.commit();

    }

    public void f1(String itemName, int position) {
        FragmentManager fman = getSupportFragmentManager();
        FragmentTransaction fTran = fman.beginTransaction();

        ItemFragment iF = new ItemFragment();

        Bundle bundle = new Bundle();
        bundle.putString("itemName", itemName);
        bundle.putInt("position",position);

        iF.setArguments(bundle);
        fTran.replace(R.id.frameMain,iF);

        fTran.commit();
    }
}
