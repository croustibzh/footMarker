package com.georgebrown.comp2074.assignment2101137290;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.lang.reflect.Array;

public class DBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "items.db";
    public static final String TABLE = "items_table";


    private static String ID = "id";
    public static String ITEM_NAME = "item_name";


    public DBHandler(Context context){
        super(context,DATABASE_NAME ,null,DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE "+ TABLE + " (id INTEGER PRIMARY KEY AUTOINCREMENT, item_name text)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(sqLiteDatabase);

    }


    public boolean addData(String it_name){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(ITEM_NAME, it_name);
        long results = db.insert(TABLE, null,cv);
        db.close();

        if (results==-1)
            return false;
        return true;
    }

    public void deleteItem(String s){
        SQLiteDatabase db = getWritableDatabase();
        String query = "DELETE FROM " + TABLE + " WHERE " +ITEM_NAME+ "='"+s+"';";
        db.execSQL(query);
    }

}
