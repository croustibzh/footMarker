package com.georgebrown.comp2074.assignment2101137290;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class ItemFragment extends Fragment {

    TextView textView;
    Button btnDel;
    DBHandler DBH;
    String toDel;

    public ItemFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_item, container, false);

        btnDel = (Button) v.findViewById(R.id.btnDelete);
        textView = v.findViewById(R.id.ItemName);
        final Bundle b = getArguments();
        final String name = b.getString("itemName").toString();
        if (b!=null) {
            textView.setText(b.getString("itemName"));
        }
        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DBH = new DBHandler(getContext());
                DBH.deleteItem(name);
                Toast.makeText(getContext(),"Item deleted",Toast.LENGTH_SHORT).show();
                FragmentManager manager = getFragmentManager();
                FragmentTransaction fT = manager.beginTransaction();
                ListFragment fL = new ListFragment();
                fT.replace(R.id.frameMain,fL);
                fT.commit();
            }
        });

        return v;
    }





}
