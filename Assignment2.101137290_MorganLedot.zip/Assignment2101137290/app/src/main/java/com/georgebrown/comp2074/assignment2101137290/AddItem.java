package com.georgebrown.comp2074.assignment2101137290;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddItem extends Fragment {

    public AddItem() {
        // Required empty public constructor
    }

    DBHandler dbHandler;

    Button saveAdd;
    EditText itName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View v = inflater.inflate(R.layout.fragment_add_item, container, false);

        saveAdd = v.findViewById(R.id.btnAdd);
        itName = v.findViewById(R.id.createName);
        dbHandler = new DBHandler(getContext());

        saveAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Save data into db to be implemented here

                saveData();


                FragmentManager manager = getFragmentManager();
                FragmentTransaction fT = manager.beginTransaction();
                ListFragment fL = new ListFragment();
                fT.replace(R.id.frameMain,fL);
                fT.commit();
            }
        });

        return v;
    }


    public void saveData(){
        boolean isInserted = dbHandler.addData(itName.getText().toString());
        if (isInserted){
            Toast.makeText(getContext(),"Item saved",Toast.LENGTH_SHORT).show();
        }
    }

}
